import React, { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", service: "Website", message: "" });
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus("");

    try {
      const response = await fetch("http://localhost:8000/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (data.success) {
        setStatus("success");
        setForm({ name: "", email: "", service: "Website", message: "" });
      } else {
        setStatus("error");
      }
    } catch (error) {
      console.error("Error:", error);
      setStatus("error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="contact"
      className="relative py-20 text-white overflow-hidden
                 bg-gradient-to-b from-[#0f0f25] via-[#0b0b1f] to-[#0b0f1a]
                 md:bg-none"
    >
      {/* 🎥 Background Video (Desktop only) */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0"
      >
        <source src="/videos/vdo10.mp4" type="video/mp4" />
      </video>

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/40 z-[1]"></div>

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6">
        <h2 className="text-4xl font-extrabold text-yellow-400 text-center mb-12">
          Free Consultation
        </h2>

        <div className="flex flex-col lg:flex-row gap-10">
          {/* Contact Info */}
          <div className="flex-1 flex flex-col justify-center gap-8 
  bg-gradient-to-br from-[#151a33]/80 to-[#0f1326]/80 
  backdrop-blur-xl p-8 sm:p-10 rounded-3xl 
  shadow-[0_20px_60px_rgba(0,0,0,0.6)] 
  border border-indigo-500/20 relative overflow-hidden">

            {/* Glow Decoration */}
            <div className="absolute -top-20 -right-20 w-60 h-60 bg-indigo-500/20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-yellow-400/20 rounded-full blur-3xl"></div>

            {/* Heading */}
            <h3 className="text-2xl sm:text-3xl font-extrabold text-indigo-400 tracking-wide relative z-10">
              Contact Information
            </h3>

            {/* Phone */}
            <div className="flex items-center gap-4 relative z-10">
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 flex items-center justify-center text-xl">
                📞
              </div>
              <div>
                <p className="text-sm text-gray-400">Phone</p>
                <p className="text-lg sm:text-xl font-semibold text-gray-200">
                  +91 89822 42338
                </p>
              </div>
            </div>

            {/* Email */}
            <div className="flex items-center gap-4 relative z-10">
              <div className="w-12 h-12 rounded-xl bg-yellow-400/20 flex items-center justify-center text-xl">
                ✉️
              </div>
              <div>
                <p className="text-sm text-gray-400">Email</p>
                <p className="text-lg sm:text-xl font-semibold text-gray-200">
                  contact@suprexon.com
                </p>
              </div>
            </div>

            {/* Description */}
            <p className="text-gray-400 text-sm sm:text-base leading-relaxed relative z-10">
              Get in touch with us for a <span className="text-yellow-400 font-semibold">
                free consultation</span>.
              Our experts will respond quickly and guide you with the best solution for your business.
            </p>

            {/* CTA */}
            <div className="relative z-10">
              <a
                href="#contact"
                className="inline-block mt-2 bg-indigo-500 hover:bg-indigo-400 
      text-white px-6 py-3 rounded-xl font-semibold 
      transition-all duration-300 shadow-lg hover:scale-105"
              >
                Talk to Expert →
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="flex-1">
            <form
              onSubmit={handleSubmit}
              className="relative bg-gradient-to-br from-[#151a33]/80 to-[#0f1326]/80
               backdrop-blur-xl p-8 sm:p-10 rounded-3xl
               border border-indigo-500/20
               shadow-[0_20px_60px_rgba(0,0,0,0.6)]
               flex flex-col gap-5 overflow-hidden"
            >
              {/* Decorative glow */}
              <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl"></div>
              <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-yellow-400/20 rounded-full blur-3xl"></div>

              {/* Title */}
              <h3 className="relative z-10 text-2xl font-extrabold text-yellow-400 mb-2">
                Send Your Enquiry
              </h3>

              {/* Name */}
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="👤 Your Name"
                required
                className="relative z-10 px-4 py-3 rounded-xl
                 border border-gray-700 bg-[#0f1629]
                 focus:outline-none focus:ring-2 focus:ring-indigo-500
                 text-gray-200 shadow-sm w-full"
              />

              {/* Email */}
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="✉️ Your Email"
                required
                className="relative z-10 px-4 py-3 rounded-xl
                 border border-gray-700 bg-[#0f1629]
                 focus:outline-none focus:ring-2 focus:ring-indigo-500
                 text-gray-200 shadow-sm w-full"
              />

              {/* Service Selection */}
              <div className="relative z-10">
                <label className="block text-sm text-gray-300 font-semibold mb-2">
                  Select Service
                </label>

                <div className="flex gap-4">
                  <label className="flex items-center gap-3 px-4 py-3 rounded-xl
                          bg-[#0f1629] border border-gray-700
                          cursor-pointer hover:border-yellow-400 transition">
                    <input
                      type="radio"
                      name="service"
                      value="Website"
                      checked={form.service === "Website"}
                      onChange={handleChange}
                      className="accent-yellow-400"
                    />
                    <span className="text-gray-200">🌐 Website</span>
                  </label>

                  <label className="flex items-center gap-3 px-4 py-3 rounded-xl
                          bg-[#0f1629] border border-gray-700
                          cursor-pointer hover:border-yellow-400 transition">
                    <input
                      type="radio"
                      name="service"
                      value="App"
                      checked={form.service === "App"}
                      onChange={handleChange}
                      className="accent-yellow-400"
                    />
                    <span className="text-gray-200">📱 Mobile App</span>
                  </label>
                </div>
              </div>

              {/* Message */}
              <textarea
                name="message"
                value={form.message}
                onChange={handleChange}
                placeholder="📝 Tell us about your project"
                rows="5"
                required
                className="relative z-10 px-4 py-3 rounded-xl
                 border border-gray-700 bg-[#0f1629]
                 focus:outline-none focus:ring-2 focus:ring-indigo-500
                 text-gray-200 shadow-sm resize-none w-full"
              />

              {/* Submit Button */}
              <button
                type="submit"
                className={`
    w-full
                            bg-gradient-to-r from-yellow-400 to-yellow-300
                            text-black
                            py-3
                            rounded-full
                            font-bold
                            text-sm
                            shadow-lg
                            hover:scale-105
                            hover:shadow-yellow-400/40
                            transition
  `}
              >
                {loading ? "Submitting..." : "Send Enquiry"}
              </button>

              {/* Status Messages */}
              {status === "success" && (
                <p className="relative z-10 text-green-400 text-center font-semibold mt-2">
                  ✅ Thank you! Your enquiry has been submitted.
                </p>
              )}

              {status === "error" && (
                <p className="relative z-10 text-red-400 text-center font-semibold mt-2">
                  ❌ Something went wrong. Please try again.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}