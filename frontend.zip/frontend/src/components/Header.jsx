import React, { useState } from "react";
import { HiMenu, HiX } from "react-icons/hi";
import logo from "/images/suprexon_logo.png";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header
      className=" relative 
        sticky top-0 z-50
        bg-black/40 backdrop-blur-xl
        border-b border-indigo-500/30
        shadow-[0_10px_40px_rgba(99,102,241,0.25)]
        perspective-[1200px]
      "
    >
      <div className="max-w-7xl mx-auto px-6 py-3 flex justify-between items-center">

        {/* Logo */}
        <div className="flex items-center transform-style-preserve-3d">
          <img
            src={logo}
            alt="SUPREXON Logo"
            className="
              w-28 sm:w-32 h-auto object-contain
              transition-transform duration-500
              hover:rotate-y-12 hover:-translate-z-4
              drop-shadow-[0_10px_20px_rgba(99,102,241,0.6)]
            "
          />
        </div>

        {/* Desktop Menu */}
        <nav className="hidden md:flex gap-8 text-sm sm:text-base font-medium text-gray-200">
          {["Home", "Services", "Technologies", "Careers", "Contact"].map(
            (item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="
                  relative
                  transition-all duration-300
                  hover:text-indigo-400
                  hover:-translate-y-1
                  hover:scale-110
                  after:absolute after:left-0 after:-bottom-1
                  after:w-0 after:h-[2px] after:bg-indigo-400
                  after:transition-all after:duration-300
                  hover:after:w-full
                "
              >
                {item}
              </a>
            )
          )}
        </nav>

        {/* Get Quote Button */}
        <a
          href="#contact"
          className="
            hidden md:inline-block
            bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500
            px-6 py-2 rounded-full
            text-sm sm:text-base font-semibold text-white
            shadow-[0_15px_40px_rgba(236,72,153,0.5)]
            transition-all duration-300
            hover:scale-110
            hover:-translate-y-1
            hover:shadow-pink-500/70
          "
        >
          Get Quote
        </a>

        {/* Mobile Hamburger */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="
              text-gray-200 text-3xl p-1
              transition-all duration-300
              hover:text-indigo-400
              hover:rotate-90
            "
          >
            {isOpen ? <HiX /> : <HiMenu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div
          className="
            md:hidden
            bg-black/60 backdrop-blur-xl
            border-t border-indigo-500/30
            px-6 py-4
            flex flex-col gap-4 text-center
            rounded-b-3xl
            shadow-[inset_0_10px_30px_rgba(99,102,241,0.25)]
            animate-[slideDown_0.4s_ease-out]
          "
        >
          {["Home", "Services", "Technologies", "Careers", "Contact"].map(
            (item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="
                  text-gray-200 font-semibold
                  transition-all duration-300
                  hover:text-indigo-400
                  hover:scale-110
                "
                onClick={() => setIsOpen(false)}
              >
                {item}
              </a>
            )
          )}

          <a
            href="#contact"
            className="
              bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500
              text-white px-6 py-2 rounded-full font-semibold
              shadow-[0_15px_40px_rgba(236,72,153,0.5)]
              transition-all duration-300
              hover:scale-110
              hover:-translate-y-1
            "
            onClick={() => setIsOpen(false)}
          >
            Get Quote
          </a>
        </div>
      )}
    </header>
  );
}