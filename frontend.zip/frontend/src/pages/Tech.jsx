import React, { useRef, useEffect, useState } from "react";
export default function Tech() {
  const techs = [
     { name: "React", icon: "⚛️", detail: "A JavaScript library for building UI." },
    { name: "Node.js", icon: "🟢", detail: "JavaScript runtime built on Chrome’s V8 engine for scalable backend services." },
    { name: "MERN Stack", icon: "💻", detail: "MongoDB, Express, React, Node.js full-stack development." },
    { name: "Laravel", icon: "🟥", detail: "PHP framework for building secure, scalable APIs and web applications." },
    { name: "PHP", icon: "🐘", detail: "Server-side scripting language for web development." },
    { name: "JavaScript", icon: "🧠", detail: "Programming language for web development and interactivity." },
    { name: "SQL / MySQL", icon: "🛢️", detail: "Relational database management and queries." },
    { name: "Android", icon: "📱", detail: "Mobile application development platform." },
    { name: "Android Studio", icon: "🧪", detail: "Official IDE for Android app development using Java, Kotlin, and XML." },
    { name: "Tailwind", icon: "🎨", detail: "Utility-first CSS framework for styling." },
    { name: "Bootstrap", icon: "🧩", detail: "CSS framework for responsive design." },
    { name: "Java", icon: "☕", detail: "Object-oriented programming language for apps and backend." },
    { name: "HTML", icon: "📄", detail: "Markup language for creating web pages." },
    { name: "jQuery", icon: "⚡", detail: "JavaScript library for DOM manipulation and events." },
    { name: "AJAX", icon: "🌐", detail: "Technique for asynchronous web requests." },
    // NEW technologies added
    { name: "XAMPP", icon: "🖥️", detail: "Local server environment for PHP and MySQL development." },
    { name: "LAMP", icon: "🖧", detail: "Linux, Apache, MySQL, PHP stack for web development." },
    { name: "NGINX", icon: "🔥", detail: "High-performance web server and reverse proxy server." },
    { name: "MongoDB", icon: "🍃", detail: "NoSQL database for flexible, scalable data storage." },
    { name: "Firebase", icon: "☁️", detail: "Backend platform for building web & mobile apps with real-time database and authentication." },
    { name: "SQLite", icon: "🗄️", detail: "Lightweight relational database for mobile and small apps." },
  
  ];
  const containerRef = useRef(null);
  const [activeTech, setActiveTech] = useState(null); // For modal // Auto-scroll / rotate effect
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let scrollAmount = 0;
    const scrollWidth = container.scrollWidth / 2;

    const speed = 3; // 🔥 increase this (2–6 best)
    const interval = setInterval(() => {
      scrollAmount += speed;

      if (scrollAmount >= scrollWidth) {
        scrollAmount = 0;
        container.scrollLeft = 0;
      } else {
        container.scrollLeft = scrollAmount;
      }
    }, 40); // ~60fps (FAST & SMOOTH)

    return () => clearInterval(interval);
  }, []);
  return (
    <section className="relative py-20 overflow-hidden" id="tech">
      {/* Video Background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
      >
        <source src="/videos/vdo1.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Overlay for darker effect */}
      <div className="absolute top-0 left-0 w-full h-full bg-black/40 z-0"></div>

      {/* Section Content */}
      <div className="relative z-10 container mx-auto px-6 text-center text-white">
        <h2 className="text-3xl sm:text-4xl font-extrabold text-center text-yellow-400 mb-12 relative z-10"> Technologies</h2>
        {/* Auto-rotating horizontal scroll */}
        <div ref={containerRef} className="flex gap-6 overflow-x-auto px-6 py-4 hide-scrollbar" >
          {[...techs, ...techs].map((tech, index) => (
            <div key={index} className="relative flex-shrink-0 w-32 sm:w-36 md:w-40 bg-[#12172b] border border-gray-800 rounded-2xl p-4 flex flex-col items-center justify-center shadow-md hover:shadow-indigo-500 transform hover:-translate-y-1 hover:scale-105 transition-all duration-500 cursor-pointer text-sm" onClick={() => setActiveTech(tech)} >
              <span className="text-4xl">{tech.icon}</span>
              <span className="font-medium text-gray-300 mt-1 text-center text-xs sm:text-sm"> {tech.name} </span>
              {/* Glow overlay */}
              <div className="absolute inset-0 rounded-2xl bg-indigo-500/10 blur-xl opacity-0 hover:opacity-25 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>
        <p className="mt-8 max-w-3xl mx-auto text-sm sm:text-base text-gray-400 leading-relaxed animate-fadeInUp" style={{ animationDelay: '1s' }}>
          <span className="font-extrabold text-white">SupreXon Technologies</span> – Professional Software & Website Development.
          We leverage modern technologies to deliver{' '}
          <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-semibold drop-shadow-[0_0_8px_rgba(149,167,255,0.45)]">
            high-quality web & mobile applications
          </span>{' '}
          for our clients.
        </p>{/* Modal for tech details */}
        {activeTech && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 px-4">
            <div className="bg-[#0f1629] p-6 rounded-3xl max-w-sm w-full relative shadow-2xl">
              <button onClick={() => setActiveTech(null)} className="absolute top-4 right-4 text-gray-400 hover:text-white text-xl" > ✕ </button>
              <div className="flex items-center gap-4 mb-4">
                <span className="text-5xl">{activeTech.icon}</span>
                <h3 className="text-2xl font-bold text-yellow-400">{activeTech.name}</h3>
              </div>
              <p className="text-gray-300 text-sm">{activeTech.detail}</p>
            </div>
          </div>)}  </div>
    </section>);
}