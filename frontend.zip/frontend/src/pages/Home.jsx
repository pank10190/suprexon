import { useState, useEffect } from "react";
import Services from "./Services";
import Tech from "./Tech";
import Contact from "./Contact";
import Career from "./Career";
import { FaWhatsapp } from "react-icons/fa";

export default function Home() {
  const videos = [
    "/videos/vdo1.avi",
    "/videos/vdo2.mp4",
    "/videos/vdo3.mp4",
    "/videos/vdo4.mp4",
    "/videos/vdo5.mp4",
    "/videos/vdo6.mp4",
    "/videos/vdo7.mp4",
    "/videos/vdo8.mp4","/videos/vdo10.mp4",
    "/videos/vdo9.mp4",
  ];

  const [videoIndex, setVideoIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setVideoIndex((prev) => (prev + 1) % videos.length);
    }, 10000);
    return () => clearInterval(interval);
    
  }, []);

  return (
    <>
      {/* ================= HERO ================= */}
    <section
  id="home"
  className="relative min-h-screen flex items-center text-white overflow-hidden"
>
  {/* Background Video */}
  <video
    key={videoIndex}
    autoPlay
    loop
    muted
    playsInline
    className="absolute inset-0 w-full h-full object-cover z-0"
  >
    <source src={videos[videoIndex]} type="video/mp4" />
  </video>

  {/* Overlay */}
  <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/80 z-10"></div>

  {/* Content */}
  <div className="relative z-20 container mx-auto px-6">
    <div className="max-w-3xl text-center md:text-left">

      {/* Badge */}
      <span className="inline-block mb-4 px-3 py-1 text-xs sm:text-sm font-semibold rounded-full bg-indigo-500/20 text-indigo-300 animate-fadeInUp">
        🚀 Trusted Web & App Development Partner
      </span>

      {/* Headline */}
      <h1 className="text-2xl sm:text-3xl md:text-4xl xl:text-5xl font-extrabold leading-snug tracking-tight animate-fadeInUp">
        We Build&nbsp;
        <span className="relative inline-block">
          <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Websites & Mobile Apps
          </span>
          <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-indigo-400 to-purple-500 rounded-full opacity-70 blur-sm"></span>
        </span>
        <br />
        <span className="text-white font-medium animate-fadeInUp" style={{ animationDelay: '0.3s', fontSize: '0.9em' }}>
          That Grow Your Business
        </span>
      </h1>

      {/* Description */}
      <p className="mt-4 sm:mt-6 max-w-2xl text-sm sm:text-base md:text-lg text-gray-300 leading-relaxed animate-fadeInUp" style={{ animationDelay: '0.6s' }}>
        <span className="font-semibold text-white">SupreXon Technologies</span> delivers scalable, secure, and high-performance
        <span className="text-indigo-300 font-medium"> web, mobile & custom software solutions</span> for startups and growing enterprises.
      </p>

      {/* CTA Buttons */}
      <div className="mt-8 flex flex-wrap gap-4 justify-center md:justify-start">
        {/* Primary CTA */}
        <a
          href="#contact"
          className="group relative inline-flex items-center justify-center px-6 py-3 rounded-xl font-extrabold text-base sm:text-lg
            bg-gradient-to-r from-yellow-400 to-yellow-300 text-black shadow-[0_10px_30px_rgba(250,204,21,0.35)]
            transition-all duration-300 hover:scale-105 hover:shadow-[0_15px_50px_rgba(250,204,21,0.55)]"
        >
          <span className="relative z-10">Get Free Consultation</span>
          <span className="ml-1 relative z-10 transition-transform group-hover:translate-x-1">→</span>
          <span className="absolute inset-0 rounded-xl bg-yellow-400 blur-xl opacity-30 group-hover:opacity-60 transition"></span>
        </a>

        {/* Secondary CTA */}
        <a
          href="#services"
          className="group relative inline-flex items-center justify-center px-6 py-3 rounded-xl font-bold text-base sm:text-lg
            text-white border border-white/30 backdrop-blur-md bg-white/5
            transition-all duration-300 hover:bg-white hover:text-black hover:scale-105"
        >
          <span className="relative z-10">Explore Services</span>
          <span className="absolute inset-0 rounded-xl border border-white/20 group-hover:border-yellow-400/60 transition"></span>
        </a>
      </div>

      {/* Optional Stats (small, subtle) */}
      <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center text-gray-400 text-xs sm:text-sm animate-fadeInUp" style={{ animationDelay: '0.9s' }}>
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-yellow-400">100+</h3>
          <p>Projects</p>
        </div>
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-yellow-400">80+</h3>
          <p>Clients</p>
        </div>
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-yellow-400">5+</h3>
          <p>Years Experience</p>
        </div>
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-yellow-400">20+</h3>
          <p>Technologies</p>
        </div>
      </div>
    </div>
  </div>

  {/* Scroll Indicator */}
  <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20">
    <div className="w-6 h-10 border-2 border-white/60 rounded-full flex justify-center">
      <span className="w-1 h-2 bg-white rounded-full mt-2 animate-scroll"></span>
    </div>
  </div>
</section>

      {/* ================= SECTIONS ================= */}
      <Services />
      <Tech />
      <Contact />
      <Career />

      {/* WhatsApp Button */}
      <a
        href="https://wa.me/918982242338"
        target="_blank"
        rel="noopener noreferrer"
        className="
    fixed bottom-6 right-6 z-50
    bg-green-500 text-white p-4 rounded-full
    shadow-lg shadow-green-400/50
    hover:shadow-2xl hover:shadow-green-500/70
    transform hover:scale-110
    transition-all duration-300
    ring-2 ring-green-400/30 hover:ring-green-500/50
  "
      >
        <FaWhatsapp size={28} />
      </a>
    </>
  );
}