import { useEffect, useState } from "react";
import logo from "/images/suprexon_logo.png";
import {
  FaFacebookF,
  FaTwitter,
  FaLinkedinIn,
  FaInstagram,
} from "react-icons/fa";

export default function Footer() {
  const [bgIndex, setBgIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setBgIndex((prev) => (prev + 1) % 4);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <footer className="relative isolate overflow-hidden text-gray-400">
      {/* ================= BACKGROUND VIDEO ================= */}
      <video
        autoPlay
        loop
        muted
        playsInline
        preload="metadata"
        className="absolute inset-0 w-full h-full object-cover -z-20 opacity-30 pointer-events-none"
      >
        <source src="/videos/vdo1.mp4" type="video/mp4" />
      </video>

      {/* ================= DARK OVERLAY ================= */}
      <div className="absolute inset-0 bg-black/50 -z-10 pointer-events-none"></div>

      {/* ================= CONTENT ================= */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-16 grid md:grid-cols-3 gap-12">

        {/* ===== LOGO & ABOUT ===== */}
        <div className="space-y-4">
          <img
            src={logo}
            alt="SUPREXON Logo"
            className="w-32 mx-auto md:mx-0"
          />

          <p className="text-center md:text-left max-w-md text-sm sm:text-base leading-relaxed text-gray-300">
            <span className="font-semibold text-white text-lg">
              SUPREXON Technologies
            </span>{" "}
            is a professional{" "}
            <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-medium">
              software & app development company
            </span>{" "}
            delivering{" "}
            <span className="text-indigo-300 font-medium">scalable</span> and{" "}
            <span className="text-pink-400 font-medium">
              innovative digital solutions
            </span>.
          </p>

          {/* Social Icons */}
          <div className="flex gap-4 pt-2 justify-center md:justify-start">
            {[FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram].map(
              (Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="
                    w-10 h-10 flex items-center justify-center rounded-full
                    bg-gray-800 text-gray-300
                    hover:bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500
                    hover:text-white
                    transition-all duration-500
                    hover:scale-110
                    shadow-lg
                  "
                >
                  <Icon size={16} />
                </a>
              )
            )}
          </div>
        </div>

        {/* ===== SERVICES ===== */}
        <div className="space-y-6">
          <h3 className="text-yellow-400 font-bold text-xl">Services</h3>

          <ul className="space-y-3">
            {[
              "Website Development",
              "Software Solutions",
              "Mobile App Development",
              "UI / UX Design",
            ].map((service, i) => (
              <li
                key={i}
                className="relative group flex items-center gap-2 cursor-pointer"
              >
                <span className="w-2 h-2 rounded-full bg-indigo-400"></span>

                <span className="font-medium text-gray-300 bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {service}
                </span>

                <span className="absolute left-0 -bottom-0.5 w-0 h-[2px] bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 group-hover:w-full transition-all duration-500"></span>
              </li>
            ))}
          </ul>
        </div>

        {/* ===== CONTACT ===== */}
        <div className="space-y-3">
          <h3 className="text-yellow-400 font-extrabold text-2xl tracking-wide">
            Contact
          </h3>

          <a
            href="tel:+918982242338"
            className="flex items-center gap-2 p-2 rounded-2xl
              text-gray-300 hover:text-white
              hover:bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500
              transition-all duration-500 hover:scale-105 shadow-lg"
          >
            <span className="text-xl">📞</span>
            <span>+91 89822 42338</span>
          </a>

          <a
            href="mailto:contact@suprexon.com"
            className="flex items-center gap-2 p-2 rounded-2xl
              text-gray-300 hover:text-white
              hover:bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500
              transition-all duration-500 hover:scale-105 shadow-lg"
          >
            <span className="text-xl">✉️</span>
            <span>contact@suprexon.com</span>
          </a>

          <div className="flex items-center gap-2 p-2 rounded-2xl shadow-lg">
            <span className="text-xl">📍</span>
            <span>Pune, Maharashtra, India</span>
          </div>

          <div className="space-y-1 p-2 rounded-2xl shadow-lg text-sm">
            <p>
              ⏰ Mon – Fri:{" "}
              <span className="text-gray-200 font-semibold">
                08:00 PM – 01:00 AM
              </span>
            </p>
            <p>
              ⏰ Sat – Sun:{" "}
              <span className="text-gray-200 font-semibold">
                11:00 AM – 06:00 PM
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* ================= FOOTER BOTTOM ================= */}
      <div className="relative z-10 mt-6 pb-6">
        <div className="h-[2px] w-24 mx-auto mb-2 rounded-full bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 opacity-70"></div>

        <p className="text-center text-gray-400 text-xs sm:text-sm">
          © {new Date().getFullYear()}{" "}
          <span className="font-semibold text-white">
            SUPREXON Technologies
          </span>
          . All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}